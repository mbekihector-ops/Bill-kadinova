Bill KadiNova — Digital Invitations

Files included:
- index.html — website structure
- style.css — responsive navy-and-gold styling
- script.js — language switch, USD/TZS display toggle, opening invitation cards, event form, preview, QR code, flip preview, sharing, and payment-interface demo

Upload all three files to the ROOT of your new GitHub repository. Replace same-named old files, then Commit changes.

Important limitations:
- The QR code encodes the invitation details as text; it is not a public hosted invitation URL.
- USD/TZS prices are sample display values (the TZS exchange rate is only an example).
- Real payments, secure checkout, accounts, order storage, and server-side saving are not connected.
- QR images need an internet connection to load from the QR service.
- Owner contact details are included in the page.
